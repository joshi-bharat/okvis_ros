/*
 * VioVisualizer_test.cpp
 *
 *  Created on: Sep 15, 2014
 *      Author: pascal
 */

#include "VioVisualizer.hpp"

/// \brief okvis Main namespace of this package.
namespace okvis {

} /* namespace okvis */
